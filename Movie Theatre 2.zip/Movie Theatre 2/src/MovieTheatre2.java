import java.util.Scanner;
import java.text.DecimalFormat;

public class MovieTheatre2 {

	public static void main(String[] args) 
	{
		Scanner input = new Scanner(System.in);
		DecimalFormat df = new DecimalFormat("$.00");
		
		double popc, candy, pop, subtotal, hst, grandtotal, amttendered; 
		
		System.out.printf("%-29s", "Enter the amount of popcorn: ");
		popc = input.nextDouble();
		
		System.out.printf("%-29s", "Enter the amount of candy: ");
		candy = input.nextDouble();
		
		System.out.printf("%-29s", "Enter the amount of pop: ");
		pop = input.nextDouble();
		
		popc = popc * 4.29; 
		candy = candy * 3.49; 
		pop = pop * 1.99; 
		
		subtotal = popc + candy + pop; 
		hst = 0.13 * subtotal; 
		grandtotal = subtotal + hst; 
		
		System.out.printf("%-20s %9s", "Subtotal: " , df.format(subtotal) );
		System.out.printf("\n%-20s %9s", "HST: " , df.format(hst));
		System.out.printf("\n%-20s %9s", "Grand Total: " , df.format(grandtotal));

	
		System.out.printf("\n%-27s ", "Enter the amount tendered: ");
		amttendered = input.nextDouble();
		double change = amttendered - grandtotal; 
		
		System.out.printf("%-20s %9s", "Change: ", df.format(change));
		
		
		
	}

}
